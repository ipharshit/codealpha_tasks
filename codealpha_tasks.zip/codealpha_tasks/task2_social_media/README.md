# Task 2 — Social Media Platform

A mini social media application built with React.js as part of the CodeAlpha Web Development Internship.

## Features

| Feature | Details |
|---|---|
| User Profiles | Cover photo, avatar, bio, location, website, join date |
| Posts | Create, view, like, and share text + image posts |
| Comments | Threaded comments on every post |
| Like System | Heart toggle with live counter |
| Follow System | Follow/unfollow any user, feed updates instantly |
| Explore | Browse all posts + live user search |
| Notifications | Activity feed: likes, follows, comments, reshares |
| Auth | Login / Register (demo accounts below) |

## Demo Accounts

| Username | Name |
|---|---|
| `alex_creates` | Alex Chen |
| `sarah_explores` | Sarah Mitchell |
| `tech_thoughts` | Jordan Park |
| `foodie_vibes` | Emma Rodriguez |
| `fitness_fox` | Marcus Lee |
| `cozy_reads` | Lily Thompson |

> Any password works for the demo — it's frontend-only.

## Tech Stack

- **React.js** (functional components, hooks)
- **CSS-in-JS** (inline styles, no external CSS framework)
- **Google Fonts** (DM Sans)

## File

```
src/
└── SocialMediaApp.jsx    ← main component (single file, self-contained)
```

## How to Run Locally

```bash
# Option A — Create React App
npx create-react-app social-media-app
cd social-media-app
# Copy SocialMediaApp.jsx to src/
# In src/index.js change: import App from './SocialMediaApp';
npm start

# Option B — Vite
npm create vite@latest social-media-app -- --template react
cd social-media-app
npm install
# Copy SocialMediaApp.jsx to src/
# In src/main.jsx change: import App from './SocialMediaApp';
npm run dev
```

## Instant Online Preview

1. Open [stackblitz.com/edit/react](https://stackblitz.com/edit/react)
2. Paste the full contents of `SocialMediaApp.jsx` into `src/App.js`
3. Click Run ▶

## Data Model (Frontend Simulation)

```
Users       → id, username, name, bio, avatar, color, location
Posts       → id, userId, text, image, timestamp
Comments    → id, postId, userId, text, timestamp
Follows     → { followerId, followingId }
Likes       → { userId, postId }
```

All data is managed in React state. To connect a real backend, replace state arrays with API calls to `GET /api/feed`, `POST /api/posts`, `POST /api/follow/:id`, etc.
