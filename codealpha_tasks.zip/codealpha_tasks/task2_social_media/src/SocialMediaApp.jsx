import { useState, useEffect } from "react";

/* ─────────────── Design tokens ─────────────── */
const PRI  = "#111827";
const ACC  = "#5046E5";
const PINK = "#E84393";
const BG   = "#ECEEF2";
const CARD = "#FFFFFF";
const MUT  = "#6B7280";
const BRD  = "#E5E7EB";

/* ─────────────── Seed data ─────────────── */
const ALL_USERS = [
  { id:1, un:"alex_creates",   name:"Alex Chen",      bio:"Designer & developer 🚀 Building things that matter",                      av:"AC", clr:"#5046E5", cover:"linear-gradient(140deg,#667eea,#764ba2)", loc:"San Francisco", web:"alexchen.dev",  join:"Jan 2024" },
  { id:2, un:"sarah_explores", name:"Sarah Mitchell", bio:"Travel photographer 📸 | 47 countries | Adventure seeker",                  av:"SM", clr:"#E84393", cover:"linear-gradient(140deg,#f093fb,#f5576c)", loc:"New York",       web:"",              join:"Mar 2023" },
  { id:3, un:"tech_thoughts",  name:"Jordan Park",    bio:"Software engineer | OSS enthusiast | Coffee addict ☕",                     av:"JP", clr:"#10B981", cover:"linear-gradient(140deg,#43e97b,#38f9d7)", loc:"Austin TX",      web:"jordanpark.io", join:"Jun 2022" },
  { id:4, un:"foodie_vibes",   name:"Emma Rodriguez", bio:"Food blogger 🍳 | Recipe dev | Turning ingredients into extraordinary meals",av:"ER", clr:"#F59E0B", cover:"linear-gradient(140deg,#f7971e,#ffd200)", loc:"Chicago IL",     web:"",              join:"Sep 2023" },
  { id:5, un:"fitness_fox",    name:"Marcus Lee",     bio:"Personal trainer 💪 | Nutrition coach | Helping you become your best self",  av:"ML", clr:"#3B82F6", cover:"linear-gradient(140deg,#4facfe,#00f2fe)", loc:"Miami FL",       web:"",              join:"Nov 2022" },
  { id:6, un:"cozy_reads",     name:"Lily Thompson",  bio:"Bookworm 📚 | Literary critic | Finding magic in every page | she/her",      av:"LT", clr:"#8B5CF6", cover:"linear-gradient(140deg,#a18cd1,#fbc2eb)", loc:"Seattle WA",     web:"",              join:"Apr 2023" },
];

const INIT_POSTS = [
  { id:1, uid:2, text:"Sunrise at 4,000m in the Dolomites. No filter, no editing — just pure alpine magic ✨", img:"linear-gradient(140deg,#667eea,#764ba2)", em:"🌄", t:"2h ago" },
  { id:2, uid:1, text:"Just shipped a major redesign after 3 months of iteration. The team's dedication was incredible. Here's to the next challenge! 🚀", img:"linear-gradient(140deg,#f093fb,#f5576c)", em:"🎨", t:"4h ago" },
  { id:3, uid:3, text:"Hot take: clean code is not about following rules — it's empathy for the next developer. Code is communication first, instruction second 💭", img:null, em:"💡", t:"6h ago" },
  { id:4, uid:4, text:"3-ingredient chocolate mousse turned out INCREDIBLE. Dark chocolate + eggs + cream, whipped to perfection. Recipe in the comments! 🍫", img:"linear-gradient(140deg,#5f2c82,#49a09d)", em:"🍫", t:"8h ago" },
  { id:5, uid:5, text:"Monday motivation: you don't need motivation to start. You need discipline to build the habit that creates momentum. Start small, stay consistent 💪🔥", img:null, em:"💪", t:"10h ago" },
  { id:6, uid:6, text:"Finished 'The Midnight Library' and I'm still thinking about it — regret, choice, and what makes life worth living. Highly recommend 📚⭐", img:"linear-gradient(140deg,#a18cd1,#fbc2eb)", em:"📚", t:"12h ago" },
  { id:7, uid:2, text:"Golden hour in Santorini. Blue domes against that sunset — 47 countries and this never gets old 🇬🇷🌅", img:"linear-gradient(140deg,#f7971e,#ffd200)", em:"🌅", t:"1d ago" },
  { id:8, uid:3, text:"Spent the weekend on a new side project. The web ecosystem's DX has improved so much lately — building for the web is genuinely fun again ⚡", img:null, em:"⚡", t:"1d ago" },
];

const INIT_CMTS = [
  { id:1,  pid:1, uid:1, text:"Absolutely breathtaking! Those colours are unreal 😍", t:"1h ago" },
  { id:2,  pid:1, uid:5, text:"Nature's filter is always the best. Stunning shot Sarah!", t:"45m ago" },
  { id:3,  pid:2, uid:3, text:"Congrats! The redesign looks incredible — attention to detail really shows 🙌", t:"3h ago" },
  { id:4,  pid:2, uid:6, text:"The iteration process is brutal but so worth it when you see the result!", t:"2h ago" },
  { id:5,  pid:3, uid:1, text:"Empathy-driven code. Borrowing this phrase for my next retro 🙏", t:"5h ago" },
  { id:6,  pid:4, uid:2, text:"3 ingredients?? No way! Need the full recipe ASAP 😤", t:"7h ago" },
  { id:7,  pid:5, uid:6, text:"Saving this for every Monday morning! Exactly what I needed 🙌", t:"9h ago" },
  { id:8,  pid:6, uid:3, text:"I sobbed at the ending. Still processing. Great rec!", t:"11h ago" },
  { id:9,  pid:7, uid:4, text:"Santorini in person is even more stunning. Confirmed!", t:"23h ago" },
  { id:10, pid:8, uid:1, text:"Which stack? Always hunting for better DX tools!", t:"20h ago" },
];

const INIT_FOLLOWS = [
  {fr:1,fi:2},{fr:1,fi:3},{fr:2,fi:1},{fr:2,fi:4},
  {fr:3,fi:1},{fr:3,fi:5},{fr:4,fi:2},{fr:4,fi:6},
  {fr:5,fi:1},{fr:5,fi:3},{fr:6,fi:2},{fr:6,fi:4},
];

const INIT_LIKES = [
  {uid:2,pid:2},{uid:3,pid:2},{uid:4,pid:2},{uid:5,pid:2},
  {uid:1,pid:1},{uid:3,pid:1},{uid:5,pid:1},
  {uid:1,pid:3},{uid:2,pid:3},{uid:6,pid:3},
  {uid:2,pid:4},{uid:5,pid:4},{uid:1,pid:4},
  {uid:1,pid:5},{uid:2,pid:5},{uid:4,pid:5},
  {uid:3,pid:6},{uid:1,pid:6},
  {uid:3,pid:7},{uid:4,pid:7},{uid:5,pid:7},
  {uid:1,pid:8},{uid:2,pid:8},{uid:4,pid:8},
];

/* ─────────────── Outer helpers (no closure needed) ─────────────── */
const inputStyle = {
  width:"100%", padding:"10px 14px", borderRadius:8,
  border:`1.5px solid ${BRD}`, fontSize:14, outline:"none",
  fontFamily:"DM Sans, sans-serif", boxSizing:"border-box",
};

function Field({ label, children }) {
  return (
    <div>
      <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6, color:PRI }}>{label}</label>
      {children}
    </div>
  );
}

function Empty({ icon, text }) {
  return (
    <div style={{ textAlign:"center", padding:"44px 20px", color:MUT }}>
      <div style={{ fontSize:40, marginBottom:10 }}>{icon}</div>
      <div style={{ fontSize:14 }}>{text}</div>
    </div>
  );
}

/* ─────────────── Main component ─────────────── */
export default function SocialSpark() {
  const [me,       setMe]       = useState(null);
  const [posts,    setPosts]    = useState(INIT_POSTS);
  const [cmts,     setCmts]     = useState(INIT_CMTS);
  const [follows,  setFollows]  = useState(INIT_FOLLOWS);
  const [likes,    setLikes]    = useState(INIT_LIKES);
  const [view,     setView]     = useState("feed");
  const [selUser,  setSelUser]  = useState(null);
  const [selPost,  setSelPost]  = useState(null);
  const [authMode, setAuthMode] = useState("login");
  const [authForm, setAuthForm] = useState({ name:"", un:"", email:"", pw:"" });
  const [showNew,  setShowNew]  = useState(false);
  const [draft,    setDraft]    = useState("");
  const [newCmt,   setNewCmt]   = useState("");
  const [search,   setSearch]   = useState("");
  const [profTab,  setProfTab]  = useState("posts");
  const [toast,    setToast]    = useState(null);

  useEffect(() => {
    const lk = document.createElement("link");
    lk.rel  = "stylesheet";
    lk.href = "https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap";
    document.head.appendChild(lk);
  }, []);

  /* ── computed helpers ── */
  const pop      = msg => { setToast(msg); setTimeout(() => setToast(null), 2400); };
  const getU     = id  => ALL_USERS.find(u => u.id === id) || ALL_USERS[0];
  const isLiked  = pid => !!(me && likes.some(l => l.uid === me.id && l.pid === pid));
  const likeN    = pid => likes.filter(l => l.pid === pid).length;
  const cmtN     = pid => cmts.filter(c => c.pid === pid).length;
  const isFlw    = uid => !!(me && follows.some(f => f.fr === me.id && f.fi === uid));
  const flwrN    = uid => follows.filter(f => f.fi === uid).length;
  const flwgN    = uid => follows.filter(f => f.fr === uid).length;
  const uPosts   = uid => posts.filter(p => p.uid === uid);
  const uLiked   = uid => posts.filter(p => likes.some(l => l.uid === uid && l.pid === p.id));

  const feedPosts = me
    ? posts.filter(p => p.uid === me.id || follows.some(f => f.fr === me.id && f.fi === p.uid))
    : posts;

  /* ── actions ── */
  const toggleLike = pid => {
    if (!me) return;
    setLikes(prev => {
      const has = prev.some(l => l.uid === me.id && l.pid === pid);
      return has
        ? prev.filter(l => !(l.uid === me.id && l.pid === pid))
        : [...prev, { uid: me.id, pid }];
    });
  };

  const toggleFollow = uid => {
    if (!me || uid === me.id) return;
    const has = follows.some(f => f.fr === me.id && f.fi === uid);
    setFollows(prev =>
      has ? prev.filter(f => !(f.fr === me.id && f.fi === uid))
          : [...prev, { fr: me.id, fi: uid }]
    );
    pop(has ? "Unfollowed" : `Following ${getU(uid).name}! 🎉`);
  };

  const submitPost = () => {
    if (!draft.trim()) return;
    setPosts(prev => [
      { id: Date.now(), uid: me.id, text: draft.trim(), img: null, em: "✍️", t: "just now" },
      ...prev,
    ]);
    setDraft(""); setShowNew(false); pop("Posted! ✅");
  };

  const submitCmt = pid => {
    if (!newCmt.trim()) return;
    setCmts(prev => [...prev, { id: Date.now(), pid, uid: me.id, text: newCmt.trim(), t: "just now" }]);
    setNewCmt(""); pop("Comment added!");
  };

  const handleLogin = e => {
    e.preventDefault();
    const found = ALL_USERS.find(u => u.un === authForm.un.trim());
    const user  = authMode === "login"
      ? (found || ALL_USERS[0])
      : { ...ALL_USERS[0], name: authForm.name || "New User", un: authForm.un || "new_user" };
    setMe(user);
    setAuthForm({ name:"", un:"", email:"", pw:"" });
    pop("Welcome! 👋");
  };

  const goProfile = u => { setSelUser(u); setView("profile"); setProfTab("posts"); };
  const goPost    = p => { setSelPost(p); setView("post"); };

  const suggestions = me
    ? ALL_USERS.filter(u => u.id !== me.id && !follows.some(f => f.fr === me.id && f.fi === u.id)).slice(0, 3)
    : ALL_USERS.slice(0, 3);

  const searchRes = search.trim()
    ? ALL_USERS.filter(u =>
        u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.un.toLowerCase().includes(search.toLowerCase()))
    : [];

  /* ── inline sub-components (closures over state) ── */
  const Av = ({ uid, size, noNav }) => {
    const sz = size || 40;
    const u  = getU(uid);
    return (
      <div
        onClick={noNav ? undefined : () => goProfile(u)}
        style={{
          width: sz, height: sz, borderRadius: "50%", background: u.clr,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: sz * 0.36, fontWeight: 700, color: "white",
          flexShrink: 0, cursor: noNav ? "default" : "pointer",
          userSelect: "none", fontFamily: "DM Sans, sans-serif",
        }}>
        {u.av}
      </div>
    );
  };

  const PostCard = ({ post }) => {
    const author  = getU(post.uid);
    const liked   = isLiked(post.id);
    const isMine  = !!(me && post.uid === me.id);
    const flwing  = isFlw(post.uid);
    return (
      <div style={{
        background: CARD, borderRadius: 14, marginBottom: 12,
        boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
        borderLeft: `4px solid ${author.clr}`,
      }}>
        <div style={{ padding: "14px 16px" }}>
          {/* Author row */}
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 10 }}>
            <Av uid={author.id} size={38} />
            <div style={{ flex: 1, overflow: "hidden" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                <span
                  onClick={() => goProfile(author)}
                  style={{ fontWeight: 700, fontSize: 14, cursor: "pointer" }}
                  onMouseEnter={e => { e.currentTarget.style.textDecoration = "underline"; }}
                  onMouseLeave={e => { e.currentTarget.style.textDecoration = "none"; }}>
                  {author.name}
                </span>
                <span style={{ color: MUT, fontSize: 12 }}>@{author.un} · {post.t}</span>
                {!isMine && me && (
                  <button
                    onClick={() => toggleFollow(post.uid)}
                    style={{
                      marginLeft: "auto", padding: "3px 12px", borderRadius: 100,
                      fontSize: 11, fontWeight: 600, cursor: "pointer",
                      fontFamily: "DM Sans, sans-serif",
                      border: `1.5px solid ${flwing ? BRD : ACC}`,
                      background: flwing ? "transparent" : ACC,
                      color: flwing ? PRI : "white",
                    }}>
                    {flwing ? "Following" : "Follow"}
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Content */}
          <div style={{ marginLeft: 48 }}>
            <p
              onClick={() => goPost(post)}
              style={{ margin: "0 0 10px", fontSize: 14, lineHeight: 1.7, color: PRI, cursor: "pointer" }}>
              {post.text}
            </p>
            {post.img && (
              <div
                onClick={() => goPost(post)}
                style={{
                  background: post.img, borderRadius: 10, height: 148, cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 50, marginBottom: 10, userSelect: "none",
                }}>
                {post.em}
              </div>
            )}
            {/* Action row */}
            <div style={{ display: "flex", gap: 18, alignItems: "center" }}>
              <button
                onClick={() => goPost(post)}
                style={{ display: "flex", alignItems: "center", gap: 5, background: "none", border: "none", cursor: "pointer", fontSize: 13, color: MUT, fontFamily: "inherit" }}>
                <span style={{ fontSize: 15 }}>💬</span>{cmtN(post.id)}
              </button>
              <button
                onClick={() => toggleLike(post.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 5, background: "none", border: "none",
                  cursor: "pointer", fontSize: 13, fontFamily: "inherit",
                  color: liked ? PINK : MUT, fontWeight: liked ? 700 : 400, transition: "color 0.15s",
                }}>
                <span style={{ fontSize: 15 }}>{liked ? "❤️" : "🤍"}</span>{likeN(post.id)}
              </button>
              <button style={{ display: "flex", alignItems: "center", gap: 5, background: "none", border: "none", cursor: "pointer", fontSize: 13, color: MUT, fontFamily: "inherit" }}>
                <span style={{ fontSize: 15 }}>🔁</span>{Math.floor(post.id * 1.8)}
              </button>
              <button style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer", fontSize: 15, color: MUT }}>🔖</button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const UserRow = ({ u }) => (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
      <Av uid={u.id} size={36} />
      <div style={{ flex: 1, overflow: "hidden" }}>
        <div
          onClick={() => goProfile(u)}
          style={{ fontWeight: 700, fontSize: 13, cursor: "pointer", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {u.name}
        </div>
        <div style={{ color: MUT, fontSize: 11 }}>@{u.un}</div>
      </div>
      {me && u.id !== me.id && (
        <button
          onClick={() => toggleFollow(u.id)}
          style={{
            padding: "4px 12px", borderRadius: 100, fontSize: 11, fontWeight: 600,
            cursor: "pointer", fontFamily: "DM Sans, sans-serif", flexShrink: 0,
            border: `1.5px solid ${isFlw(u.id) ? BRD : ACC}`,
            background: isFlw(u.id) ? "transparent" : ACC,
            color: isFlw(u.id) ? PRI : "white",
          }}>
          {isFlw(u.id) ? "✓" : "Follow"}
        </button>
      )}
    </div>
  );

  const NavBtn = ({ icon, label, v }) => (
    <button
      onClick={() => { setView(v); if (v === "profile") setSelUser(me); }}
      style={{
        display: "flex", alignItems: "center", gap: 12, padding: "10px 14px",
        borderRadius: 12, width: "100%", border: "none", cursor: "pointer",
        fontFamily: "DM Sans, sans-serif", textAlign: "left", marginBottom: 3,
        background: view === v ? "#EDEAFF" : "transparent",
        color: view === v ? ACC : PRI,
        fontWeight: view === v ? 700 : 500, fontSize: 14,
      }}>
      <span style={{ fontSize: 18 }}>{icon}</span>
      {label}
    </button>
  );

  /* ══════════════ AUTH SCREEN ══════════════ */
  if (!me) {
    return (
      <div style={{
        minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
        background: "linear-gradient(140deg,#5046E5 0%,#E84393 100%)",
        fontFamily: "DM Sans, sans-serif",
      }}>
        <div style={{
          background: CARD, borderRadius: 24, padding: "44px 40px",
          width: 420, maxWidth: "90vw", boxShadow: "0 28px 70px rgba(0,0,0,0.22)",
        }}>
          <div style={{ textAlign: "center", marginBottom: 28 }}>
            <div style={{
              width: 56, height: 56, borderRadius: 16,
              background: "linear-gradient(140deg,#5046E5,#E84393)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 26, margin: "0 auto 14px",
            }}>💬</div>
            <h1 style={{ fontSize: 26, fontWeight: 800, margin: "0 0 6px", color: PRI, letterSpacing: -0.5 }}>SocialSpark</h1>
            <p style={{ color: MUT, fontSize: 14 }}>
              {authMode === "login" ? "Welcome back — sign in to continue." : "Join the conversation today."}
            </p>
          </div>

          <form onSubmit={handleLogin} style={{ display: "grid", gap: 14 }}>
            {authMode === "register" && (
              <>
                <Field label="Full Name">
                  <input
                    value={authForm.name}
                    onChange={e => setAuthForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Alex Chen"
                    style={inputStyle} />
                </Field>
                <Field label="Email">
                  <input
                    value={authForm.email}
                    onChange={e => setAuthForm(f => ({ ...f, email: e.target.value }))}
                    placeholder="you@email.com"
                    type="email"
                    style={inputStyle} />
                </Field>
              </>
            )}
            <Field label="Username">
              <div style={{ position: "relative" }}>
                <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: MUT }}>@</span>
                <input
                  value={authForm.un}
                  onChange={e => setAuthForm(f => ({ ...f, un: e.target.value }))}
                  placeholder="alex_creates"
                  style={{ ...inputStyle, paddingLeft: 28 }} />
              </div>
              {authMode === "login" && (
                <div style={{ fontSize: 11, color: MUT, marginTop: 5 }}>
                  💡 Try: alex_creates · sarah_explores · tech_thoughts
                </div>
              )}
            </Field>
            <Field label="Password">
              <input
                value={authForm.pw}
                onChange={e => setAuthForm(f => ({ ...f, pw: e.target.value }))}
                placeholder="••••••••"
                type="password"
                style={inputStyle} />
            </Field>
            <button
              type="submit"
              style={{
                padding: 14, border: "none", color: "white", borderRadius: 12,
                fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", marginTop: 4,
                background: "linear-gradient(140deg,#5046E5,#8B5CF6)",
                boxShadow: "0 4px 16px rgba(80,70,229,0.35)",
              }}>
              {authMode === "login" ? "Sign In" : "Create Account"}
            </button>
          </form>

          <p style={{ textAlign: "center", marginTop: 18, color: MUT, fontSize: 13 }}>
            {authMode === "login" ? "New here? " : "Already have an account? "}
            <button
              onClick={() => setAuthMode(m => m === "login" ? "register" : "login")}
              style={{ background: "none", border: "none", color: ACC, cursor: "pointer", fontWeight: 700, fontFamily: "inherit", fontSize: 13 }}>
              {authMode === "login" ? "Create Account →" : "Sign In"}
            </button>
          </p>
        </div>
      </div>
    );
  }

  /* ══════════════ NOTIFICATION DATA ══════════════ */
  const notifs = [
    { id:1, icon:"❤️", text:`${getU(2).name} liked your post`,           t:"2h ago",  clr: getU(2).clr },
    { id:2, icon:"👥", text:`${getU(3).name} started following you`,      t:"4h ago",  clr: getU(3).clr },
    { id:3, icon:"💬", text:`${getU(4).name} commented: "Amazing work!"`, t:"6h ago",  clr: getU(4).clr },
    { id:4, icon:"❤️", text:`${getU(5).name} liked your latest photo`,    t:"1d ago",  clr: getU(5).clr },
    { id:5, icon:"👥", text:`${getU(6).name} started following you`,      t:"1d ago",  clr: getU(6).clr },
    { id:6, icon:"🔁", text:`${getU(2).name} reshared your post`,         t:"2d ago",  clr: getU(2).clr },
  ];

  /* ══════════════ MAIN APP ══════════════ */
  return (
    <div style={{ minHeight: "100vh", background: BG, fontFamily: "DM Sans, sans-serif", color: PRI }}>

      {/* Toast */}
      {toast && (
        <div style={{
          position: "fixed", top: 20, right: 20, zIndex: 9999,
          background: PRI, color: "white", padding: "11px 18px",
          borderRadius: 10, fontSize: 14, fontWeight: 500,
          boxShadow: "0 6px 24px rgba(0,0,0,0.18)",
        }}>
          {toast}
        </div>
      )}

      {/* Create-post modal */}
      {showNew && (
        <>
          <div
            onClick={() => setShowNew(false)}
            style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 500 }} />
          <div style={{
            position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)",
            background: CARD, borderRadius: 20, padding: 28, width: 520, maxWidth: "90vw",
            zIndex: 501, boxShadow: "0 24px 64px rgba(0,0,0,0.18)",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
              <span style={{ fontWeight: 800, fontSize: 17 }}>New Post</span>
              <button onClick={() => setShowNew(false)} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: MUT }}>×</button>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <Av uid={me.id} size={40} noNav={true} />
              <div style={{ flex: 1 }}>
                <textarea
                  value={draft}
                  onChange={e => setDraft(e.target.value)}
                  placeholder={`What's on your mind, ${me.name.split(" ")[0]}?`}
                  rows={4}
                  style={{
                    width: "100%", border: "none", outline: "none", fontSize: 16,
                    resize: "none", fontFamily: "inherit", color: PRI,
                    lineHeight: 1.7, boxSizing: "border-box",
                  }} />
                <div style={{ borderTop: `1px solid ${BRD}`, paddingTop: 12, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ display: "flex", gap: 10 }}>
                    {["📷", "🎬", "😊", "📍"].map(ic => (
                      <button key={ic} style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer", opacity: 0.5 }}>{ic}</button>
                    ))}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 12, color: draft.length > 240 ? PINK : MUT }}>{280 - draft.length}</span>
                    <button
                      onClick={submitPost}
                      disabled={!draft.trim()}
                      style={{
                        padding: "9px 22px", border: "none", color: "white", borderRadius: 100,
                        fontWeight: 700, fontSize: 14, fontFamily: "inherit",
                        cursor: draft.trim() ? "pointer" : "default",
                        background: draft.trim() ? "linear-gradient(140deg,#5046E5,#8B5CF6)" : "#DDD",
                      }}>
                      Post
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* App shell */}
      <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex" }}>

        {/* ── LEFT NAV ── */}
        <aside style={{
          width: 190, flexShrink: 0, padding: "20px 10px",
          position: "sticky", top: 0, height: "100vh",
          display: "flex", flexDirection: "column", overflow: "auto",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 24, padding: "0 8px" }}>
            <div style={{
              width: 34, height: 34, borderRadius: 10,
              background: "linear-gradient(140deg,#5046E5,#E84393)",
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
            }}>💬</div>
            <span style={{ fontWeight: 800, fontSize: 17, letterSpacing: -0.5 }}>SocialSpark</span>
          </div>

          <NavBtn icon="🏠" label="Home"          v="feed" />
          <NavBtn icon="🔍" label="Explore"       v="explore" />
          <NavBtn icon="🔔" label="Notifications" v="notifications" />
          <NavBtn icon="👤" label="Profile"       v="profile" />

          <button
            onClick={() => setShowNew(true)}
            style={{
              marginTop: 14, padding: 13, border: "none", color: "white",
              borderRadius: 12, fontWeight: 700, fontSize: 14,
              cursor: "pointer", fontFamily: "inherit", width: "100%",
              background: "linear-gradient(140deg,#5046E5,#8B5CF6)",
              boxShadow: "0 4px 14px rgba(80,70,229,0.3)",
            }}>
            ✏️ New Post
          </button>

          <div style={{ flex: 1 }} />

          {/* User chip */}
          <div
            onClick={() => { setSelUser(me); setView("profile"); }}
            style={{
              display: "flex", alignItems: "center", gap: 8, padding: "10px",
              borderRadius: 12, background: "#F3F4F6", cursor: "pointer", marginTop: 12,
            }}>
            <div style={{
              width: 34, height: 34, borderRadius: "50%", background: me.clr,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 14, fontWeight: 700, color: "white", flexShrink: 0,
            }}>
              {me.av}
            </div>
            <div style={{ flex: 1, overflow: "hidden" }}>
              <div style={{ fontWeight: 700, fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{me.name}</div>
              <div style={{ color: MUT, fontSize: 10 }}>@{me.un}</div>
            </div>
            <button
              onClick={e => { e.stopPropagation(); setMe(null); }}
              title="Sign out"
              style={{ background: "none", border: "none", color: MUT, cursor: "pointer", fontSize: 16, flexShrink: 0 }}>
              ↩
            </button>
          </div>
        </aside>

        {/* ── MAIN CONTENT ── */}
        <main style={{
          flex: 1, minWidth: 0,
          borderLeft: `1px solid ${BRD}`, borderRight: `1px solid ${BRD}`,
          minHeight: "100vh", padding: "18px 16px",
        }}>

          {/* ── FEED ── */}
          {view === "feed" && (
            <div>
              <div style={{ fontWeight: 800, fontSize: 19, marginBottom: 14, letterSpacing: -0.3 }}>Home</div>

              {/* Quick compose */}
              <div style={{
                background: CARD, borderRadius: 14, padding: "14px 16px", marginBottom: 14,
                boxShadow: "0 1px 4px rgba(0,0,0,0.06)", display: "flex", gap: 10, alignItems: "center",
              }}>
                <Av uid={me.id} size={36} noNav={true} />
                <div
                  onClick={() => setShowNew(true)}
                  style={{ flex: 1, padding: "9px 16px", borderRadius: 100, background: BG, cursor: "text", color: MUT, fontSize: 14 }}>
                  What's on your mind, {me.name.split(" ")[0]}?
                </div>
                <button
                  onClick={() => setShowNew(true)}
                  style={{
                    padding: "8px 16px", border: "none", color: "white", borderRadius: 100,
                    fontWeight: 600, fontSize: 13, cursor: "pointer", fontFamily: "inherit",
                    background: "linear-gradient(140deg,#5046E5,#8B5CF6)",
                  }}>
                  Post
                </button>
              </div>

              {feedPosts.length === 0
                ? <Empty icon="📭" text="Follow some people to see their posts here!" />
                : feedPosts.map(p => <PostCard key={p.id} post={p} />)
              }
            </div>
          )}

          {/* ── EXPLORE ── */}
          {view === "explore" && (
            <div>
              <div style={{ fontWeight: 800, fontSize: 19, marginBottom: 14, letterSpacing: -0.3 }}>Explore</div>
              <div style={{ position: "relative", marginBottom: 18 }}>
                <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: MUT }}>🔍</span>
                <input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search people…"
                  style={{
                    width: "100%", padding: "11px 14px 11px 40px", borderRadius: 100,
                    border: `1.5px solid ${BRD}`, fontSize: 14, outline: "none",
                    fontFamily: "inherit", background: CARD, boxSizing: "border-box",
                  }} />
              </div>

              {search.trim() ? (
                <div>
                  <div style={{ fontWeight: 600, fontSize: 12, color: MUT, marginBottom: 10, textTransform: "uppercase", letterSpacing: 0.8 }}>
                    Results for "{search}"
                  </div>
                  {searchRes.length === 0
                    ? <Empty icon="🔎" text="No users found" />
                    : searchRes.map(u => (
                        <div key={u.id} style={{ background: CARD, borderRadius: 12, padding: "12px 14px", marginBottom: 10, boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}>
                          <UserRow u={u} />
                        </div>
                      ))
                  }
                </div>
              ) : (
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12 }}>📈 Trending</div>
                  {posts.map(p => <PostCard key={p.id} post={p} />)}
                </div>
              )}
            </div>
          )}

          {/* ── NOTIFICATIONS ── */}
          {view === "notifications" && (
            <div>
              <div style={{ fontWeight: 800, fontSize: 19, marginBottom: 14, letterSpacing: -0.3 }}>Notifications</div>
              {notifs.map(n => (
                <div key={n.id} style={{
                  background: CARD, borderRadius: 12, padding: "14px 16px", marginBottom: 10,
                  display: "flex", alignItems: "center", gap: 14,
                  boxShadow: "0 1px 4px rgba(0,0,0,0.06)", borderLeft: `4px solid ${n.clr}`,
                }}>
                  <span style={{ fontSize: 22, flexShrink: 0 }}>{n.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, color: PRI }}>{n.text}</div>
                    <div style={{ fontSize: 12, color: MUT, marginTop: 2 }}>{n.t}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ── PROFILE ── */}
          {view === "profile" && selUser && (
            <div>
              {selUser.id !== me.id && (
                <button
                  onClick={() => setView("feed")}
                  style={{ background: "none", border: "none", color: PRI, cursor: "pointer", fontSize: 14, marginBottom: 12, fontFamily: "inherit", padding: 0, display: "flex", alignItems: "center", gap: 6 }}>
                  ← Back
                </button>
              )}

              {/* Profile header */}
              <div style={{ background: CARD, borderRadius: 16, overflow: "hidden", marginBottom: 12, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" }}>
                <div style={{ height: 90, background: selUser.cover }} />
                <div style={{ padding: "0 20px 20px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: -28, marginBottom: 12 }}>
                    <div style={{
                      width: 64, height: 64, borderRadius: "50%", background: selUser.clr,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 24, fontWeight: 700, color: "white", border: "4px solid white",
                    }}>
                      {selUser.av}
                    </div>
                    {selUser.id !== me.id ? (
                      <button
                        onClick={() => toggleFollow(selUser.id)}
                        style={{
                          padding: "9px 20px", borderRadius: 100, fontWeight: 700, fontSize: 13,
                          cursor: "pointer", fontFamily: "inherit",
                          border: `2px solid ${isFlw(selUser.id) ? BRD : ACC}`,
                          background: isFlw(selUser.id) ? "transparent" : "linear-gradient(140deg,#5046E5,#8B5CF6)",
                          color: isFlw(selUser.id) ? PRI : "white",
                        }}>
                        {isFlw(selUser.id) ? "Following ✓" : "Follow"}
                      </button>
                    ) : (
                      <button style={{ padding: "9px 20px", borderRadius: 100, fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit", border: `2px solid ${BRD}`, background: "white", color: PRI }}>
                        Edit Profile
                      </button>
                    )}
                  </div>
                  <div style={{ fontWeight: 800, fontSize: 18, letterSpacing: -0.3 }}>{selUser.name}</div>
                  <div style={{ color: MUT, fontSize: 13, marginBottom: 8 }}>@{selUser.un}</div>
                  <p style={{ fontSize: 14, lineHeight: 1.65, marginBottom: 10, color: PRI }}>{selUser.bio}</p>
                  <div style={{ display: "flex", gap: 12, color: MUT, fontSize: 12, marginBottom: 12, flexWrap: "wrap" }}>
                    {selUser.loc && <span>📍 {selUser.loc}</span>}
                    {selUser.web && <span>🔗 {selUser.web}</span>}
                    <span>📅 Joined {selUser.join}</span>
                  </div>
                  <div style={{ display: "flex", gap: 20, fontSize: 14 }}>
                    <span><strong>{flwgN(selUser.id)}</strong> <span style={{ color: MUT }}>Following</span></span>
                    <span><strong>{flwrN(selUser.id)}</strong> <span style={{ color: MUT }}>Followers</span></span>
                    <span><strong>{uPosts(selUser.id).length}</strong> <span style={{ color: MUT }}>Posts</span></span>
                  </div>
                </div>
              </div>

              {/* Tabs */}
              <div style={{ display: "flex", background: CARD, borderRadius: 12, marginBottom: 12, overflow: "hidden", boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}>
                {[["posts", "Posts"], ["likes", "❤️ Liked"]].map(([tab, lbl]) => (
                  <button key={tab} onClick={() => setProfTab(tab)}
                    style={{
                      flex: 1, padding: "12px", border: "none", cursor: "pointer",
                      fontFamily: "inherit", fontSize: 14,
                      fontWeight: profTab === tab ? 700 : 500,
                      background: "transparent", color: profTab === tab ? ACC : MUT,
                      borderBottom: `3px solid ${profTab === tab ? ACC : "transparent"}`,
                    }}>
                    {lbl}
                  </button>
                ))}
              </div>

              {(profTab === "posts" ? uPosts(selUser.id) : uLiked(selUser.id)).map(p => (
                <PostCard key={p.id} post={p} />
              ))}
              {(profTab === "posts" ? uPosts(selUser.id) : uLiked(selUser.id)).length === 0 && (
                <Empty icon={profTab === "posts" ? "📝" : "🤍"} text={`No ${profTab} yet`} />
              )}
            </div>
          )}

          {/* ── POST DETAIL ── */}
          {view === "post" && selPost && (
            <div>
              <button
                onClick={() => setView("feed")}
                style={{ background: "none", border: "none", color: PRI, cursor: "pointer", fontSize: 14, marginBottom: 12, fontFamily: "inherit", padding: 0, display: "flex", alignItems: "center", gap: 6 }}>
                ← Back
              </button>
              <PostCard post={selPost} />

              {/* Comments section */}
              <div style={{ background: CARD, borderRadius: 14, padding: "18px", boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}>
                <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 14 }}>
                  Comments ({cmtN(selPost.id)})
                </div>

                {/* Compose comment */}
                <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
                  <Av uid={me.id} size={34} noNav={true} />
                  <div style={{ flex: 1 }}>
                    <textarea
                      value={newCmt}
                      onChange={e => setNewCmt(e.target.value)}
                      placeholder="Write a comment…"
                      rows={2}
                      style={{
                        width: "100%", border: `1.5px solid ${BRD}`, borderRadius: 10,
                        padding: "9px 12px", fontSize: 14, resize: "none",
                        outline: "none", fontFamily: "inherit", boxSizing: "border-box",
                      }} />
                    <button
                      onClick={() => submitCmt(selPost.id)}
                      disabled={!newCmt.trim()}
                      style={{
                        marginTop: 8, padding: "8px 18px", border: "none", color: "white",
                        borderRadius: 8, fontWeight: 600, fontSize: 13, fontFamily: "inherit",
                        cursor: newCmt.trim() ? "pointer" : "default",
                        background: newCmt.trim() ? "linear-gradient(140deg,#5046E5,#8B5CF6)" : "#DDD",
                      }}>
                      Reply
                    </button>
                  </div>
                </div>

                {/* Comment list */}
                {cmts.filter(c => c.pid === selPost.id).map(c => {
                  const cu = getU(c.uid);
                  return (
                    <div key={c.id} style={{ display: "flex", gap: 10, marginBottom: 14 }}>
                      <div
                        onClick={() => goProfile(cu)}
                        style={{
                          width: 34, height: 34, borderRadius: "50%", background: cu.clr,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 13, fontWeight: 700, color: "white", flexShrink: 0, cursor: "pointer",
                        }}>
                        {cu.av}
                      </div>
                      <div style={{ flex: 1, background: BG, borderRadius: 12, padding: "10px 14px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4, flexWrap: "wrap" }}>
                          <span onClick={() => goProfile(cu)} style={{ fontWeight: 700, fontSize: 13, cursor: "pointer" }}>{cu.name}</span>
                          <span style={{ color: MUT, fontSize: 11 }}>@{cu.un} · {c.t}</span>
                        </div>
                        <p style={{ margin: 0, fontSize: 14, color: PRI, lineHeight: 1.65 }}>{c.text}</p>
                      </div>
                    </div>
                  );
                })}

                {cmtN(selPost.id) === 0 && (
                  <div style={{ textAlign: "center", padding: "16px 0", color: MUT, fontSize: 14 }}>
                    Be the first to comment!
                  </div>
                )}
              </div>
            </div>
          )}
        </main>

        {/* ── RIGHT SIDEBAR ── */}
        <aside style={{ width: 220, flexShrink: 0, padding: "20px 14px" }}>
          <div style={{ background: CARD, borderRadius: 16, padding: "16px", marginBottom: 14, boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}>
            <div style={{ fontWeight: 700, fontSize: 12, marginBottom: 14, textTransform: "uppercase", letterSpacing: 0.9, color: MUT }}>
              Who to Follow
            </div>
            {suggestions.length > 0
              ? suggestions.map(u => <UserRow key={u.id} u={u} />)
              : <div style={{ color: MUT, fontSize: 13 }}>You're all caught up! 🎉</div>
            }
          </div>

          <div style={{ background: CARD, borderRadius: 16, padding: "16px", boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}>
            <div style={{ fontWeight: 700, fontSize: 12, marginBottom: 14, textTransform: "uppercase", letterSpacing: 0.9, color: MUT }}>
              Trending
            </div>
            {[["#WebDev","12.4k"],["#Travel","8.7k"],["#FoodLovers","6.1k"],["#Fitness","4.9k"],["#BookClub","3.2k"]].map(([tag, ct], i) => (
              <div key={tag} style={{ marginBottom: 12, cursor: "pointer", paddingBottom: 12, borderBottom: i < 4 ? `1px solid ${BRD}` : "none" }}>
                <div style={{ fontSize: 10, color: MUT, textTransform: "uppercase", letterSpacing: 0.5 }}>Trending #{i + 1}</div>
                <div style={{ fontWeight: 700, fontSize: 13, marginTop: 2 }}>{tag}</div>
                <div style={{ fontSize: 11, color: MUT }}>{ct} posts</div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
