# Task 1 — Simple E-commerce Store

A fully functional e-commerce store built with React.js as part of the CodeAlpha Web Development Internship.

## Features

| Feature | Details |
|---|---|
| Product Listings | 12 products, 4 categories, live search & filter |
| Shopping Cart | Add/remove items, quantity controls, free shipping at $100 |
| User Auth | Register & Login modal |
| Checkout | 3-step flow: Shipping → Payment → Review |
| Order Confirmation | Unique order ID + estimated delivery date |
| Wishlist | Save products across sessions |
| Colour Selector | Per-product variant picking |
| Notifications | Toast messages for all actions |

## Tech Stack

- **React.js** (functional components, hooks)
- **CSS-in-JS** (inline styles, no external CSS framework)
- **Google Fonts** (Playfair Display + Inter)

## File

```
src/
└── EcommerceStore.jsx    ← main component (single file, self-contained)
```

## How to Run Locally

```bash
# Option A — Create React App
npx create-react-app ecommerce-store
cd ecommerce-store
# Copy EcommerceStore.jsx to src/
# In src/index.js change: import App from './EcommerceStore';
npm start

# Option B — Vite
npm create vite@latest ecommerce-store -- --template react
cd ecommerce-store
npm install
# Copy EcommerceStore.jsx to src/
# In src/main.jsx change: import App from './EcommerceStore';
npm run dev
```

## Instant Online Preview

1. Open [stackblitz.com/edit/react](https://stackblitz.com/edit/react)
2. Paste the full contents of `EcommerceStore.jsx` into `src/App.js`
3. Click Run ▶

## Screenshot Preview

> Login → Browse products → Filter by category → Add to cart → Checkout → Order confirmed
