import { useState, useEffect } from "react";

const PRI = "#1B2340";
const ACC = "#F4633A";
const BG  = "#F9F8F6";
const OK  = "#27AE60";
const BRD = "#E8E4DF";

const PRODUCTS = [
  { id:1,  name:"Wireless Headphones Pro",   price:149.99, cat:"Electronics",  rating:4.5, reviews:128, em:"🎧", desc:"Premium noise-cancelling headphones with 30-hr battery, spatial audio, and foldable design for travel.", stock:15, badge:"Best Seller",  colors:["Black","White","Navy"] },
  { id:2,  name:"Smart Fitness Watch",        price:299.99, cat:"Electronics",  rating:4.7, reviews:89,  em:"⌚", desc:"GPS + heart-rate fitness tracker with 7-day battery, sleep tracking, and 50m water resistance.",    stock:8,  badge:"New Arrival",  colors:["Black","Silver","Rose Gold"] },
  { id:3,  name:"Leather Laptop Bag",         price:89.99,  cat:"Accessories",  rating:4.3, reviews:215, em:"💼", desc:"Full-grain leather bag for 15.6\" laptops. Padded compartments, brass hardware, adjustable strap.", stock:22, badge:null,           colors:["Brown","Black"] },
  { id:4,  name:"Mechanical Keyboard",        price:129.99, cat:"Electronics",  rating:4.8, reviews:341, em:"⌨️", desc:"Compact 75% RGB board with hot-swap tactile switches, USB-C detachable cable, and per-key lighting.",stock:11, badge:"Top Rated",    colors:["White","Black"] },
  { id:5,  name:"Adjustable Desk Lamp",       price:59.99,  cat:"Home & Living",rating:4.4, reviews:67,  em:"💡", desc:"LED lamp with 5 brightness levels, 3 colour temps, and a built-in USB-A charging port.",           stock:30, badge:null,           colors:["White","Black","Brass"] },
  { id:6,  name:"Running Shoes Elite",        price:119.99, cat:"Sports",       rating:4.6, reviews:189, em:"👟", desc:"Ultra-light mesh uppers with responsive foam cushioning. Breathable, durable, true to size.",         stock:5,  badge:"Low Stock",    colors:["Black/Red","White/Blue","Grey"] },
  { id:7,  name:"Programmable Coffee Maker",  price:199.99, cat:"Home & Living",rating:4.5, reviews:94,  em:"☕", desc:"12-cup brewer with integrated conical burr grinder, thermal carafe, and auto-clean cycle.",           stock:18, badge:null,           colors:["Stainless","Matte Black"] },
  { id:8,  name:"Yoga Mat Pro",               price:45.99,  cat:"Sports",       rating:4.2, reviews:302, em:"🧘", desc:"6mm eco-TPE non-slip mat with alignment markings and a carrying strap included.",                  stock:40, badge:null,           colors:["Purple","Teal","Black","Coral"] },
  { id:9,  name:"Power Bank 20K",             price:39.99,  cat:"Electronics",  rating:4.6, reviews:512, em:"🔋", desc:"20,000mAh with 65W USB-C PD fast charge. Charge three devices at once.",                          stock:25, badge:"Fan Favorite",  colors:["Black","White"] },
  { id:10, name:"Insulated Water Bottle",     price:34.99,  cat:"Sports",       rating:4.7, reviews:423, em:"🧊", desc:"32oz double-wall stainless steel. Cold 24hr, hot 12hr. Leak-proof lid, BPA-free.",                 stock:50, badge:null,           colors:["Charcoal","Ocean Blue","Forest","Cream"] },
  { id:11, name:"Ergonomic Wireless Mouse",   price:49.99,  cat:"Electronics",  rating:4.4, reviews:178, em:"🖱️", desc:"Silent-click ergonomic design. Adjustable DPI 800-4000. 18-month battery life.",                   stock:20, badge:null,           colors:["Black","White"] },
  { id:12, name:"Aromatherapy Candle Set",    price:29.99,  cat:"Home & Living",rating:4.3, reviews:156, em:"🕯️", desc:"4 hand-poured soy candles: Lavender, Vanilla, Cedar, Ocean. 40+ hr burn time each.",               stock:35, badge:null,           colors:["Natural"] },
];

const CATS = ["All","Electronics","Accessories","Home & Living","Sports"];

const badgeColor = b => b === "Low Stock" ? "#E74C3C" : b === "New Arrival" ? OK : ACC;

export default function ShopCraft() {
  const [view,       setView]       = useState("shop");
  const [cart,       setCart]       = useState([]);
  const [user,       setUser]       = useState(null);
  const [sel,        setSel]        = useState(null);
  const [showCart,   setShowCart]   = useState(false);
  const [showAuth,   setShowAuth]   = useState(false);
  const [authMode,   setAuthMode]   = useState("login");
  const [cat,        setCat]        = useState("All");
  const [search,     setSearch]     = useState("");
  const [order,      setOrder]      = useState(null);
  const [step,       setStep]       = useState(1);
  const [toast,      setToast]      = useState(null);
  const [wish,       setWish]       = useState([]);
  const [cpick,      setCpick]      = useState({});
  const [authForm,   setAuthForm]   = useState({ name:"", email:"", pass:"" });
  const [ship,       setShip]       = useState({ name:"", email:"", addr:"", city:"", zip:"" });
  const [pay,        setPay]        = useState({ cname:"", card:"", exp:"", cvv:"" });

  useEffect(() => {
    const lk = document.createElement("link");
    lk.rel  = "stylesheet";
    lk.href = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap";
    document.head.appendChild(lk);
  }, []);

  const pop = (msg, type = "ok") => { setToast({ msg, type }); setTimeout(() => setToast(null), 2500); };

  const cartN  = cart.reduce((s, i) => s + i.qty, 0);
  const sub    = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const shpCst = sub > 100 ? 0 : sub > 0 ? 9.99 : 0;
  const tax    = sub * 0.08;
  const total  = sub + shpCst + tax;

  const addCart = p => {
    const color = cpick[p.id] || p.colors[0];
    const key   = `${p.id}|${color}`;
    setCart(prev => {
      const ex = prev.find(i => i.key === key);
      if (ex) return prev.map(i => i.key === key ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...p, key, color, qty: 1 }];
    });
    pop("Added to cart 🛒");
  };

  const updQty  = (key, d) => setCart(prev =>
    prev.map(i => i.key === key ? { ...i, qty: i.qty + d } : i).filter(i => i.qty > 0)
  );
  const remItem = key => setCart(prev => prev.filter(i => i.key !== key));

  const togWish = p => setWish(prev => {
    if (prev.includes(p.id)) { pop("Removed from wishlist"); return prev.filter(id => id !== p.id); }
    pop("Saved to wishlist ❤️"); return [...prev, p.id];
  });

  const handleAuth = e => {
    e.preventDefault();
    const name = authMode === "register" ? authForm.name : authForm.email.split("@")[0];
    setUser({ name, email: authForm.email });
    setShowAuth(false);
    setAuthForm({ name:"", email:"", pass:"" });
    if (authMode === "register") setShip(s => ({ ...s, name, email: authForm.email }));
    pop(`Welcome${authMode === "register" ? `, ${name}` : " back"}! 👋`);
  };

  const startCO = () => {
    if (!user) { setShowAuth(true); pop("Sign in to checkout", "info"); return; }
    setView("checkout"); setStep(1); setShowCart(false);
    if (!ship.name && user.name)   setShip(s => ({ ...s, name: user.name }));
    if (!ship.email && user.email) setShip(s => ({ ...s, email: user.email }));
  };

  const placeOrder = () => {
    const o = {
      id:    "ORD-" + Math.random().toString(36).slice(2,10).toUpperCase(),
      items: [...cart], total,
      date:  new Date().toLocaleDateString("en-US", { year:"numeric", month:"long", day:"numeric" }),
      eta:   new Date(Date.now() + 5*864e5).toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric" }),
    };
    setOrder(o); setCart([]); setView("confirmed");
  };

  const filtered = PRODUCTS.filter(p =>
    (cat === "All" || p.cat === cat) &&
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const Inp = ({ val, onChange, ...rest }) => (
    <input value={val} onChange={e => onChange(e.target.value)} {...rest}
      style={{ width:"100%", padding:"10px 14px", borderRadius:8, border:`1.5px solid ${BRD}`,
               fontSize:14, outline:"none", fontFamily:"Inter, sans-serif", boxSizing:"border-box" }} />
  );

  const Btn = ({ children, style={}, ...rest }) => (
    <button {...rest}
      style={{ border:"none", borderRadius:10, cursor:"pointer", fontWeight:600,
               fontFamily:"Inter, sans-serif", ...style }}>
      {children}
    </button>
  );

  const Stars = ({ r }) => (
    <span style={{ fontSize:12 }}>
      <span style={{ color:"#F59E0B" }}>{"★".repeat(Math.floor(r))}</span>
      <span style={{ color:"#DDD" }}>{"★".repeat(5 - Math.floor(r))}</span>
    </span>
  );

  return (
    <div style={{ minHeight:"100vh", background:BG, fontFamily:"Inter, sans-serif", color:PRI }}>

      {/* ── TOAST ── */}
      {toast && (
        <div style={{ position:"fixed", top:20, right:20, zIndex:9999,
                      background: toast.type === "info" ? "#3498DB" : PRI,
                      color:"white", padding:"11px 18px", borderRadius:10, fontSize:14,
                      fontWeight:500, boxShadow:"0 6px 24px rgba(0,0,0,0.18)" }}>
          {toast.msg}
        </div>
      )}

      {/* ── HEADER ── */}
      <header style={{ background:PRI, position:"sticky", top:0, zIndex:100,
                       boxShadow:"0 2px 16px rgba(0,0,0,0.14)" }}>
        <div style={{ maxWidth:1200, margin:"0 auto", padding:"0 20px", height:64,
                      display:"flex", alignItems:"center", gap:14 }}>

          <div onClick={() => { setView("shop"); setSel(null); }}
               style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer", flexShrink:0 }}>
            <div style={{ width:34, height:34, background:ACC, borderRadius:9,
                          display:"flex", alignItems:"center", justifyContent:"center", fontSize:17 }}>🛍️</div>
            <span style={{ fontFamily:"Playfair Display, serif", fontSize:20,
                           fontWeight:700, color:"white" }}>ShopCraft</span>
          </div>

          {view === "shop" && (
            <div style={{ position:"relative", width:260, marginLeft:8 }}>
              <span style={{ position:"absolute", left:10, top:"50%", transform:"translateY(-50%)",
                             color:"rgba(255,255,255,0.45)", fontSize:14 }}>🔍</span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products…"
                style={{ width:"100%", padding:"7px 10px 7px 30px", borderRadius:8,
                         border:"1.5px solid rgba(255,255,255,0.2)",
                         background:"rgba(255,255,255,0.1)", color:"white",
                         fontSize:13, outline:"none", fontFamily:"inherit", boxSizing:"border-box" }} />
            </div>
          )}

          <div style={{ flex:1 }} />

          {user ? (
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <div style={{ width:32, height:32, borderRadius:"50%", background:ACC,
                            display:"flex", alignItems:"center", justifyContent:"center",
                            fontSize:14, fontWeight:700, color:"white", flexShrink:0 }}>
                {user.name[0].toUpperCase()}
              </div>
              <span style={{ color:"white", fontSize:13 }}>{user.name}</span>
              <button onClick={() => { setUser(null); pop("Signed out"); }}
                style={{ fontSize:12, color:"rgba(255,255,255,0.45)", background:"none",
                         border:"none", cursor:"pointer", padding:"2px 6px", fontFamily:"inherit" }}>Sign out</button>
            </div>
          ) : (
            <button onClick={() => { setShowAuth(true); setAuthMode("login"); }}
              style={{ padding:"7px 16px", borderRadius:8, border:"1.5px solid rgba(255,255,255,0.3)",
                       background:"transparent", color:"white", fontSize:13, cursor:"pointer",
                       fontFamily:"inherit", fontWeight:500 }}>Sign In</button>
          )}

          <button onClick={() => setShowCart(true)}
            style={{ position:"relative", background:ACC, border:"none", color:"white",
                     width:40, height:40, borderRadius:10, cursor:"pointer",
                     fontSize:17, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
            🛒
            {cartN > 0 && (
              <span style={{ position:"absolute", top:-6, right:-6, background:"white", color:PRI,
                             borderRadius:"50%", width:18, height:18, fontSize:11, fontWeight:700,
                             display:"flex", alignItems:"center", justifyContent:"center" }}>{cartN}</span>
            )}
          </button>
        </div>
      </header>

      {/* ══════════════════════ SHOP VIEW ══════════════════════ */}
      {view === "shop" && !sel && (
        <main style={{ maxWidth:1200, margin:"0 auto", padding:"28px 20px" }}>

          {/* Hero */}
          <div style={{ background:`linear-gradient(140deg, ${PRI} 0%, #2A3B72 100%)`,
                        borderRadius:18, padding:"44px 50px", marginBottom:30,
                        position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", right:48, top:"50%", transform:"translateY(-50%) rotate(14deg)",
                          fontSize:120, opacity:0.11, pointerEvents:"none" }}>🛍️</div>
            <div>
              <div style={{ fontSize:11, fontWeight:700, letterSpacing:2.5, color:ACC,
                            textTransform:"uppercase", marginBottom:14 }}>Free shipping on orders over $100</div>
              <h1 style={{ fontFamily:"Playfair Display, serif", fontSize:40, fontWeight:700,
                           color:"white", margin:"0 0 16px", lineHeight:1.15 }}>
                Shop Smart,<br />Live Better
              </h1>
              <p style={{ color:"rgba(255,255,255,0.62)", marginBottom:26, lineHeight:1.7, maxWidth:380 }}>
                Curated essentials for home, work, and play — all in one place.
              </p>
              <Btn style={{ background:ACC, color:"white", padding:"12px 28px", fontSize:15 }}
                onClick={() => window.scrollTo({ top:300, behavior:"smooth" })}>
                Shop Now →
              </Btn>
            </div>
          </div>

          {/* Category Chips */}
          <div style={{ display:"flex", gap:8, marginBottom:22, flexWrap:"wrap", alignItems:"center" }}>
            {CATS.map(c => (
              <button key={c} onClick={() => setCat(c)}
                style={{ padding:"7px 18px", borderRadius:100,
                         border:`2px solid ${cat === c ? ACC : BRD}`,
                         background:cat === c ? ACC : "white",
                         color:cat === c ? "white" : PRI,
                         fontSize:13, fontWeight:cat === c ? 600 : 400,
                         cursor:"pointer", fontFamily:"inherit", transition:"all 0.15s" }}>
                {c}
              </button>
            ))}
            <span style={{ marginLeft:"auto", color:"#999", fontSize:13 }}>{filtered.length} items</span>
          </div>

          {/* Product Grid */}
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(230px, 1fr))", gap:18 }}>
            {filtered.map(p => (
              <div key={p.id} style={{ background:"white", borderRadius:14, overflow:"hidden",
                                       boxShadow:"0 1px 6px rgba(0,0,0,0.06)", transition:"all 0.2s" }}
                onMouseEnter={e => { e.currentTarget.style.transform="translateY(-4px)"; e.currentTarget.style.boxShadow="0 10px 28px rgba(0,0,0,0.10)"; }}
                onMouseLeave={e => { e.currentTarget.style.transform="translateY(0)"; e.currentTarget.style.boxShadow="0 1px 6px rgba(0,0,0,0.06)"; }}>

                {/* Image */}
                <div onClick={() => setSel(p)} style={{ height:170, background:"linear-gradient(135deg,#F0EDE8,#E8E4DA)",
                                                        display:"flex", alignItems:"center", justifyContent:"center",
                                                        fontSize:66, position:"relative", cursor:"pointer" }}>
                  {p.em}
                  {p.badge && (
                    <span style={{ position:"absolute", top:10, left:10, background:badgeColor(p.badge),
                                   color:"white", fontSize:10, fontWeight:700, padding:"3px 9px", borderRadius:100 }}>
                      {p.badge}
                    </span>
                  )}
                  <button onClick={e => { e.stopPropagation(); togWish(p); }}
                    style={{ position:"absolute", top:8, right:8, background:"white", border:"none",
                             width:30, height:30, borderRadius:"50%", cursor:"pointer", fontSize:14,
                             display:"flex", alignItems:"center", justifyContent:"center",
                             boxShadow:"0 2px 8px rgba(0,0,0,0.12)" }}>
                    {wish.includes(p.id) ? "❤️" : "🤍"}
                  </button>
                </div>

                {/* Info */}
                <div style={{ padding:"14px 16px 16px" }} onClick={() => setSel(p)}>
                  <div style={{ fontSize:10, color:"#999", textTransform:"uppercase", letterSpacing:1.2, marginBottom:4 }}>{p.cat}</div>
                  <div style={{ fontWeight:600, fontSize:14, marginBottom:6, lineHeight:1.3, cursor:"pointer" }}>{p.name}</div>
                  <div style={{ marginBottom:8, display:"flex", alignItems:"center", gap:5 }}>
                    <Stars r={p.rating} />
                    <span style={{ color:"#999", fontSize:11 }}>({p.reviews})</span>
                  </div>

                  {/* Colors */}
                  <div style={{ display:"flex", gap:4, marginBottom:12, flexWrap:"wrap" }}>
                    {p.colors.map(c => (
                      <button key={c} onClick={e => { e.stopPropagation(); setCpick(cp => ({ ...cp, [p.id]:c })); }}
                        style={{ fontSize:10, padding:"2px 7px", borderRadius:4, cursor:"pointer",
                                 border:`1.5px solid ${(cpick[p.id]||p.colors[0])===c ? ACC : "#DDD"}`,
                                 background:"transparent", fontFamily:"inherit",
                                 color:(cpick[p.id]||p.colors[0])===c ? ACC : "#888",
                                 fontWeight:(cpick[p.id]||p.colors[0])===c ? 600 : 400 }}>
                        {c}
                      </button>
                    ))}
                  </div>

                  <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                    <span style={{ fontSize:19, fontWeight:700 }}>${p.price.toFixed(2)}</span>
                    <Btn onClick={e => { e.stopPropagation(); addCart(p); }}
                         style={{ background:ACC, color:"white", padding:"7px 14px", fontSize:13 }}>
                      + Cart
                    </Btn>
                  </div>
                  <div style={{ fontSize:11, color:p.stock<=5?"#E74C3C":"#AAA", marginTop:6 }}>
                    {p.stock<=5 ? `⚠ Only ${p.stock} left` : "✓ In stock"}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filtered.length === 0 && (
            <div style={{ textAlign:"center", padding:"60px 20px", color:"#999" }}>
              <div style={{ fontSize:52, marginBottom:16 }}>🔍</div>
              <div style={{ fontSize:16, marginBottom:12 }}>No results for "{search}"</div>
              <Btn onClick={() => { setSearch(""); setCat("All"); }}
                style={{ background:ACC, color:"white", padding:"9px 22px", fontSize:14 }}>
                Clear filters
              </Btn>
            </div>
          )}
        </main>
      )}

      {/* ══════════════════ PRODUCT DETAIL ══════════════════ */}
      {view === "shop" && sel && (
        <div style={{ maxWidth:1000, margin:"0 auto", padding:"28px 20px" }}>
          <button onClick={() => setSel(null)}
            style={{ background:"none", border:"none", color:PRI, cursor:"pointer",
                     fontSize:14, marginBottom:20, padding:0, fontFamily:"inherit",
                     display:"flex", alignItems:"center", gap:6 }}>
            ← Back to products
          </button>
          <div style={{ background:"white", borderRadius:18, overflow:"hidden",
                        boxShadow:"0 4px 24px rgba(0,0,0,0.09)",
                        display:"grid", gridTemplateColumns:"1fr 1fr" }}>
            <div style={{ background:"linear-gradient(135deg,#F0EDE8,#E8E4DA)",
                          display:"flex", alignItems:"center", justifyContent:"center",
                          fontSize:110, minHeight:380, padding:40 }}>
              {sel.em}
            </div>
            <div style={{ padding:"44px 44px 44px 8px" }}>
              {sel.badge && (
                <span style={{ background:badgeColor(sel.badge), color:"white",
                               fontSize:11, fontWeight:700, padding:"4px 12px", borderRadius:100 }}>
                  {sel.badge}
                </span>
              )}
              <div style={{ fontSize:12, color:"#999", textTransform:"uppercase",
                            letterSpacing:1.2, marginTop:14, marginBottom:8 }}>{sel.cat}</div>
              <h1 style={{ fontFamily:"Playfair Display, serif", fontSize:26,
                           margin:"0 0 12px", lineHeight:1.3 }}>{sel.name}</h1>
              <div style={{ marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>
                <Stars r={sel.rating} />
                <span style={{ color:"#999", fontSize:13 }}>{sel.rating} · {sel.reviews} reviews</span>
              </div>
              <p style={{ color:"#666", lineHeight:1.75, marginBottom:22, fontSize:14 }}>{sel.desc}</p>

              <div style={{ marginBottom:22 }}>
                <div style={{ fontWeight:600, fontSize:13, marginBottom:8 }}>
                  Colour: <span style={{ fontWeight:400, color:"#666" }}>{cpick[sel.id]||sel.colors[0]}</span>
                </div>
                <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                  {sel.colors.map(c => (
                    <button key={c} onClick={() => setCpick(cp => ({ ...cp, [sel.id]:c }))}
                      style={{ padding:"7px 14px", borderRadius:8, cursor:"pointer",
                               border:`2px solid ${(cpick[sel.id]||sel.colors[0])===c ? ACC : BRD}`,
                               background:(cpick[sel.id]||sel.colors[0])===c ? "#FFF4F1" : "white",
                               color:PRI, fontSize:13, fontFamily:"inherit",
                               fontWeight:(cpick[sel.id]||sel.colors[0])===c ? 600 : 400 }}>
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ fontSize:30, fontWeight:700, marginBottom:20 }}>${sel.price.toFixed(2)}</div>

              <div style={{ display:"flex", gap:10, marginBottom:14 }}>
                <Btn onClick={() => addCart(sel)}
                     style={{ flex:1, background:ACC, color:"white", padding:"13px 20px", fontSize:15 }}>
                  Add to Cart
                </Btn>
                <button onClick={() => togWish(sel)}
                  style={{ padding:"13px 18px", border:`2px solid ${wish.includes(sel.id)?ACC:BRD}`,
                           background:"white", borderRadius:10, cursor:"pointer", fontSize:18 }}>
                  {wish.includes(sel.id) ? "❤️" : "🤍"}
                </button>
              </div>

              <div style={{ fontSize:12, color:sel.stock<=5?"#E74C3C":OK }}>
                {sel.stock<=5 ? `⚠ Only ${sel.stock} items left!` : `✓ In stock — ${sel.stock} available`}
              </div>
              <div style={{ marginTop:18, padding:"14px 16px", background:BG, borderRadius:10,
                            fontSize:12, color:"#777", lineHeight:2.2 }}>
                🚚 Free shipping on orders over $100 &nbsp;·&nbsp; 🔄 30-day hassle-free returns &nbsp;·&nbsp; 🛡️ 1-year warranty
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════ CHECKOUT ══════════════════════ */}
      {view === "checkout" && (
        <div style={{ maxWidth:860, margin:"0 auto", padding:"28px 20px" }}>
          <button onClick={() => { setView("shop"); setShowCart(true); }}
            style={{ background:"none", border:"none", cursor:"pointer", color:PRI,
                     fontSize:13, marginBottom:22, padding:0, fontFamily:"inherit" }}>
            ← Back to Cart
          </button>

          {/* Step indicator */}
          <div style={{ display:"flex", alignItems:"center", marginBottom:28 }}>
            {["Shipping","Payment","Review"].map((label, i) => (
              <div key={i} style={{ display:"flex", alignItems:"center", flex:i<2?1:0 }}>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <div style={{ width:30, height:30, borderRadius:"50%", color:"white",
                                background:step>i+1?OK:step===i+1?ACC:"#DDD",
                                display:"flex", alignItems:"center", justifyContent:"center",
                                fontWeight:700, fontSize:13, flexShrink:0 }}>
                    {step>i+1?"✓":i+1}
                  </div>
                  <span style={{ fontWeight:step===i+1?600:400, fontSize:14,
                                 color:step>=i+1?PRI:"#AAA" }}>{label}</span>
                </div>
                {i<2 && <div style={{ flex:1, height:2, background:step>i+1?OK:"#DDD", margin:"0 12px" }} />}
              </div>
            ))}
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:20 }}>
            {/* ─ Step 1: Shipping ─ */}
            {step===1 && (
              <div style={{ background:"white", borderRadius:14, padding:28 }}>
                <h2 style={{ fontFamily:"Playfair Display, serif", margin:"0 0 22px", fontSize:22 }}>Shipping Information</h2>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
                  {[["name","Full Name","Jane Smith"],["email","Email","jane@email.com"]].map(([k,lb,ph]) => (
                    <div key={k}>
                      <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>{lb}</label>
                      <Inp val={ship[k]} onChange={v => setShip(s=>({...s,[k]:v}))} placeholder={ph} />
                    </div>
                  ))}
                  <div style={{ gridColumn:"1/-1" }}>
                    <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>Street Address</label>
                    <Inp val={ship.addr} onChange={v => setShip(s=>({...s,addr:v}))} placeholder="123 Main Street" />
                  </div>
                  {[["city","City","New York"],["zip","ZIP Code","10001"]].map(([k,lb,ph]) => (
                    <div key={k}>
                      <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>{lb}</label>
                      <Inp val={ship[k]} onChange={v => setShip(s=>({...s,[k]:v}))} placeholder={ph} />
                    </div>
                  ))}
                </div>
                <Btn onClick={() => setStep(2)}
                     disabled={!ship.name||!ship.email||!ship.addr||!ship.city||!ship.zip}
                     style={{ marginTop:22, width:"100%", padding:13, background:ACC, color:"white", fontSize:15,
                              opacity:(!ship.name||!ship.email||!ship.addr||!ship.city||!ship.zip)?0.5:1 }}>
                  Continue to Payment →
                </Btn>
              </div>
            )}

            {/* ─ Step 2: Payment ─ */}
            {step===2 && (
              <div style={{ background:"white", borderRadius:14, padding:28 }}>
                <h2 style={{ fontFamily:"Playfair Display, serif", margin:"0 0 14px", fontSize:22 }}>Payment Details</h2>
                <div style={{ background:BG, borderRadius:9, padding:"10px 14px",
                              fontSize:12, color:"#777", marginBottom:18 }}>
                  🔒 Demo mode — enter any values, no real charges.
                </div>
                <div style={{ display:"grid", gap:14 }}>
                  <div>
                    <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>Name on Card</label>
                    <Inp val={pay.cname} onChange={v=>setPay(p=>({...p,cname:v}))} placeholder="Jane Smith" />
                  </div>
                  <div>
                    <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>Card Number</label>
                    <Inp val={pay.card} onChange={v=>setPay(p=>({...p,card:v.replace(/\D/g,"").slice(0,16)}))} placeholder="1234 5678 9012 3456" />
                  </div>
                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
                    <div>
                      <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>Expiry</label>
                      <Inp val={pay.exp} onChange={v=>setPay(p=>({...p,exp:v}))} placeholder="MM/YY" />
                    </div>
                    <div>
                      <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>CVV</label>
                      <Inp val={pay.cvv} onChange={v=>setPay(p=>({...p,cvv:v.replace(/\D/g,"").slice(0,4)}))} placeholder="123" />
                    </div>
                  </div>
                </div>
                <div style={{ display:"flex", gap:10, marginTop:22 }}>
                  <button onClick={() => setStep(1)}
                    style={{ padding:"13px 22px", border:`2px solid ${BRD}`, background:"white",
                             color:PRI, borderRadius:10, cursor:"pointer", fontFamily:"inherit", fontWeight:500, fontSize:14 }}>
                    ← Back
                  </button>
                  <Btn onClick={() => setStep(3)}
                       disabled={!pay.cname||!pay.card||!pay.exp||!pay.cvv}
                       style={{ flex:1, padding:13, background:ACC, color:"white", fontSize:15,
                                opacity:(!pay.cname||!pay.card||!pay.exp||!pay.cvv)?0.5:1 }}>
                    Review Order →
                  </Btn>
                </div>
              </div>
            )}

            {/* ─ Step 3: Review ─ */}
            {step===3 && (
              <div style={{ background:"white", borderRadius:14, padding:28 }}>
                <h2 style={{ fontFamily:"Playfair Display, serif", margin:"0 0 20px", fontSize:22 }}>Review Your Order</h2>
                {cart.map(item => (
                  <div key={item.key} style={{ display:"flex", gap:14, alignItems:"center",
                                               paddingBottom:14, marginBottom:14, borderBottom:`1px solid ${BRD}` }}>
                    <div style={{ width:52, height:52, background:"#F0EDE8", borderRadius:9,
                                  display:"flex", alignItems:"center", justifyContent:"center",
                                  fontSize:24, flexShrink:0 }}>{item.em}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontWeight:600, fontSize:14 }}>{item.name}</div>
                      <div style={{ color:"#999", fontSize:12 }}>{item.color} · Qty {item.qty}</div>
                    </div>
                    <div style={{ fontWeight:700 }}>${(item.price*item.qty).toFixed(2)}</div>
                  </div>
                ))}
                <div style={{ background:BG, borderRadius:10, padding:"12px 16px",
                              fontSize:13, color:"#666", marginBottom:20 }}>
                  <div style={{ fontWeight:600, color:PRI, marginBottom:4 }}>📦 Ship to:</div>
                  {ship.name} · {ship.addr}, {ship.city} {ship.zip}
                </div>
                <div style={{ display:"flex", gap:10 }}>
                  <button onClick={() => setStep(2)}
                    style={{ padding:"13px 22px", border:`2px solid ${BRD}`, background:"white",
                             color:PRI, borderRadius:10, cursor:"pointer", fontFamily:"inherit", fontWeight:500, fontSize:14 }}>
                    ← Back
                  </button>
                  <Btn onClick={placeOrder}
                       style={{ flex:1, padding:13, background:OK, color:"white", fontSize:15 }}>
                    ✓ Place Order — ${total.toFixed(2)}
                  </Btn>
                </div>
              </div>
            )}

            {/* Order Summary Sidebar */}
            <div style={{ background:"white", borderRadius:14, padding:22,
                          height:"fit-content", position:"sticky", top:80 }}>
              <div style={{ fontWeight:700, marginBottom:14, fontSize:15 }}>Order Summary</div>
              {cart.map(item => (
                <div key={item.key} style={{ display:"flex", justifyContent:"space-between",
                                             fontSize:13, marginBottom:7 }}>
                  <span style={{ color:"#666" }}>{item.name} ×{item.qty}</span>
                  <span style={{ fontWeight:600 }}>${(item.price*item.qty).toFixed(2)}</span>
                </div>
              ))}
              <div style={{ borderTop:`1px solid ${BRD}`, marginTop:12, paddingTop:12 }}>
                {[["Subtotal",`$${sub.toFixed(2)}`],["Shipping",shpCst===0?"FREE":`$${shpCst.toFixed(2)}`],["Tax (8%)",`$${tax.toFixed(2)}`]].map(([k,v])=>(
                  <div key={k} style={{ display:"flex", justifyContent:"space-between", fontSize:13, marginBottom:6 }}>
                    <span style={{ color:"#666" }}>{k}</span>
                    <span style={{ color:k==="Shipping"&&shpCst===0?OK:"inherit" }}>{v}</span>
                  </div>
                ))}
                <div style={{ display:"flex", justifyContent:"space-between", fontWeight:700,
                              fontSize:17, borderTop:`2px solid ${BRD}`, paddingTop:10, marginTop:4 }}>
                  <span>Total</span><span>${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════ ORDER CONFIRMED ══════════════════ */}
      {view === "confirmed" && order && (
        <div style={{ maxWidth:540, margin:"56px auto", padding:"0 20px" }}>
          <div style={{ background:"white", borderRadius:20, padding:"50px 40px",
                        boxShadow:"0 4px 32px rgba(0,0,0,0.09)", textAlign:"center" }}>
            <div style={{ width:70, height:70, background:"#EAFAF1", borderRadius:"50%",
                          display:"flex", alignItems:"center", justifyContent:"center",
                          fontSize:34, margin:"0 auto 22px" }}>✅</div>
            <h1 style={{ fontFamily:"Playfair Display, serif", fontSize:26, margin:"0 0 8px" }}>Order Confirmed!</h1>
            <p style={{ color:"#888", marginBottom:24, fontSize:14 }}>
              Thank you, {user?.name}. Your items are on their way!
            </p>
            <div style={{ background:BG, borderRadius:12, padding:"18px 20px",
                          textAlign:"left", marginBottom:20 }}>
              {[["Order ID",order.id],["Date",order.date],["Estimated Delivery",order.eta],["Total",`$${order.total.toFixed(2)}`]].map(([k,v])=>(
                <div key={k} style={{ display:"flex", justifyContent:"space-between", marginBottom:10, fontSize:14 }}>
                  <span style={{ color:"#888" }}>{k}</span>
                  <span style={{ fontWeight:k==="Order ID"||k==="Total"?700:k==="Estimated Delivery"?600:400,
                                 color:k==="Estimated Delivery"?OK:PRI }}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{ fontSize:13, color:"#999", marginBottom:24 }}>
              Confirmation sent to <strong style={{ color:PRI }}>{user?.email}</strong>
            </div>
            <Btn onClick={() => { setView("shop"); setOrder(null); }}
                 style={{ width:"100%", background:ACC, color:"white", padding:14, fontSize:15 }}>
              Continue Shopping
            </Btn>
          </div>
        </div>
      )}

      {/* ══════════════════ CART SIDEBAR ══════════════════ */}
      {showCart && (
        <>
          <div onClick={() => setShowCart(false)}
            style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.45)", zIndex:200 }} />
          <div style={{ position:"fixed", right:0, top:0, bottom:0, width:380, background:"white",
                        zIndex:201, display:"flex", flexDirection:"column",
                        boxShadow:"-4px 0 40px rgba(0,0,0,0.13)" }}>
            <div style={{ padding:"18px 22px", borderBottom:`1px solid ${BRD}`,
                          display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <span style={{ fontFamily:"Playfair Display, serif", fontSize:20, fontWeight:700 }}>Cart ({cartN})</span>
              <button onClick={() => setShowCart(false)}
                style={{ background:"none", border:"none", fontSize:22, cursor:"pointer", color:"#888", lineHeight:1 }}>×</button>
            </div>

            <div style={{ flex:1, overflow:"auto", padding:"16px 22px" }}>
              {cart.length === 0 ? (
                <div style={{ textAlign:"center", paddingTop:60, color:"#999" }}>
                  <div style={{ fontSize:52, marginBottom:14 }}>🛒</div>
                  <div style={{ marginBottom:16 }}>Your cart is empty</div>
                  <Btn onClick={() => setShowCart(false)}
                       style={{ background:ACC, color:"white", padding:"9px 20px", fontSize:14 }}>
                    Browse Products
                  </Btn>
                </div>
              ) : cart.map(item => (
                <div key={item.key} style={{ display:"flex", gap:12, marginBottom:18,
                                             paddingBottom:18, borderBottom:`1px solid ${BRD}` }}>
                  <div style={{ width:58, height:58, background:"#F0EDE8", borderRadius:9,
                                display:"flex", alignItems:"center", justifyContent:"center",
                                fontSize:27, flexShrink:0 }}>{item.em}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:600, fontSize:13, lineHeight:1.3, marginBottom:3 }}>{item.name}</div>
                    <div style={{ color:"#999", fontSize:11, marginBottom:8 }}>{item.color}</div>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      <div style={{ display:"flex", alignItems:"center", border:`1.5px solid ${BRD}`,
                                    borderRadius:7, overflow:"hidden" }}>
                        <button onClick={() => updQty(item.key,-1)}
                          style={{ width:26, height:26, border:"none", background:"none", cursor:"pointer", fontWeight:700, fontFamily:"inherit" }}>−</button>
                        <span style={{ width:26, textAlign:"center", fontSize:13, fontWeight:600 }}>{item.qty}</span>
                        <button onClick={() => updQty(item.key,+1)}
                          style={{ width:26, height:26, border:"none", background:"none", cursor:"pointer", fontWeight:700, fontFamily:"inherit" }}>+</button>
                      </div>
                      <button onClick={() => remItem(item.key)}
                        style={{ background:"none", border:"none", color:"#E74C3C", cursor:"pointer",
                                 fontSize:12, fontFamily:"inherit" }}>Remove</button>
                    </div>
                  </div>
                  <div style={{ fontWeight:700, fontSize:14, flexShrink:0 }}>${(item.price*item.qty).toFixed(2)}</div>
                </div>
              ))}
            </div>

            {cart.length > 0 && (
              <div style={{ padding:"14px 22px", borderTop:`1px solid ${BRD}` }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:13, marginBottom:5 }}>
                  <span style={{ color:"#888" }}>Subtotal</span>
                  <span style={{ fontWeight:600 }}>${sub.toFixed(2)}</span>
                </div>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:13, marginBottom:10 }}>
                  <span style={{ color:"#888" }}>Shipping</span>
                  <span style={{ color:sub>100?OK:"inherit" }}>{sub>100?"FREE":"$9.99"}</span>
                </div>
                {sub < 100 && (
                  <div style={{ fontSize:11, color:"#AAA", marginBottom:10 }}>
                    Add ${(100-sub).toFixed(2)} more for free shipping!
                  </div>
                )}
                <Btn onClick={startCO}
                     style={{ width:"100%", background:ACC, color:"white", padding:13, fontSize:15 }}>
                  Checkout · ${(sub+shpCst).toFixed(2)}
                </Btn>
              </div>
            )}
          </div>
        </>
      )}

      {/* ══════════════════ AUTH MODAL ══════════════════ */}
      {showAuth && (
        <>
          <div onClick={() => setShowAuth(false)}
            style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.5)", zIndex:300 }} />
          <div style={{ position:"fixed", top:"50%", left:"50%", transform:"translate(-50%,-50%)",
                        background:"white", borderRadius:20, padding:"40px 36px",
                        width:400, maxWidth:"90vw", zIndex:301,
                        boxShadow:"0 24px 64px rgba(0,0,0,0.16)" }}>
            <button onClick={() => setShowAuth(false)}
              style={{ position:"absolute", top:14, right:16, background:"none", border:"none",
                       fontSize:24, cursor:"pointer", color:"#888", lineHeight:1 }}>×</button>
            <div style={{ textAlign:"center", marginBottom:26 }}>
              <div style={{ fontSize:34, marginBottom:10 }}>🛍️</div>
              <h2 style={{ fontFamily:"Playfair Display, serif", fontSize:22, margin:0 }}>
                {authMode==="login" ? "Welcome Back" : "Create Account"}
              </h2>
              <p style={{ color:"#999", fontSize:13, marginTop:6 }}>
                {authMode==="login" ? "Sign in to continue shopping" : "Join thousands of happy shoppers"}
              </p>
            </div>
            <form onSubmit={handleAuth} style={{ display:"grid", gap:14 }}>
              {authMode==="register" && (
                <div>
                  <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>Full Name</label>
                  <Inp val={authForm.name} onChange={v=>setAuthForm(f=>({...f,name:v}))} placeholder="Jane Smith" />
                </div>
              )}
              <div>
                <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>Email Address</label>
                <Inp val={authForm.email} onChange={v=>setAuthForm(f=>({...f,email:v}))} placeholder="jane@example.com" type="email" />
              </div>
              <div>
                <label style={{ fontSize:12, fontWeight:600, display:"block", marginBottom:6 }}>Password</label>
                <Inp val={authForm.pass} onChange={v=>setAuthForm(f=>({...f,pass:v}))} placeholder="••••••••" type="password" />
              </div>
              <Btn type="submit" style={{ padding:13, background:ACC, color:"white", fontSize:15, marginTop:4 }}>
                {authMode==="login" ? "Sign In" : "Create Account"}
              </Btn>
            </form>
            <p style={{ textAlign:"center", marginTop:18, color:"#999", fontSize:13 }}>
              {authMode==="login" ? "No account? " : "Already registered? "}
              <button onClick={() => setAuthMode(m => m==="login"?"register":"login")}
                style={{ background:"none", border:"none", color:ACC, cursor:"pointer",
                         fontWeight:600, fontFamily:"inherit", fontSize:13 }}>
                {authMode==="login" ? "Sign Up Free" : "Sign In"}
              </button>
            </p>
          </div>
        </>
      )}
    </div>
  );
}
