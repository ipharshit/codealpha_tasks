# CodeAlpha Internship Tasks

This repository contains all frontend development tasks completed during the **CodeAlpha Web Development Internship**.

---

## 📁 Project Structure

```
codealpha_tasks/
├── task1_ecommerce/        # Task 1 – Simple E-commerce Store
└── task2_social_media/     # Task 2 – Social Media Platform
```

---

## ✅ Task 1 — Simple E-commerce Store

**Folder:** `task1_ecommerce/`

A fully functional e-commerce web application built with **React.js**.

### Features
- 🛍️ Product listings with category filter and live search
- 🛒 Shopping cart with quantity controls and free-shipping threshold
- 👤 User registration and login
- 💳 3-step checkout (Shipping → Payment → Order Review)
- ✅ Order confirmation with order ID and estimated delivery
- ❤️ Wishlist and colour selector per product
- 📦 Stock badges, toast notifications, and responsive layout

### Tech Stack
- **Frontend:** React.js, inline CSS (no extra libraries required)
- **State Management:** React Hooks (useState, useEffect)

### How to Run
```bash
cd task1_ecommerce
npx create-react-app .   # if not already set up
# Replace src/App.js content with EcommerceStore.jsx
npm start
```
Or paste `src/EcommerceStore.jsx` directly into [StackBlitz](https://stackblitz.com) or [CodeSandbox](https://codesandbox.io) for an instant preview.

---

## ✅ Task 2 — Social Media Platform

**Folder:** `task2_social_media/`

A mini social media application built with **React.js**.

### Features
- 👤 User profiles with cover photo, bio, follower/following counts
- 📝 Create, view, and browse posts (text + image cards)
- ❤️ Like / unlike posts with live counts
- 👥 Follow / unfollow users — feed updates instantly
- 💬 Comment threads on each post
- 🔍 Explore page with live user search
- 🔔 Notifications feed (likes, follows, comments)
- 🔐 Login & Register (demo accounts: `alex_creates`, `sarah_explores`, `tech_thoughts`)

### Tech Stack
- **Frontend:** React.js, inline CSS (no extra libraries required)
- **State Management:** React Hooks (useState, useEffect)

### How to Run
```bash
cd task2_social_media
npx create-react-app .   # if not already set up
# Replace src/App.js content with SocialMediaApp.jsx
npm start
```
Or paste into [StackBlitz](https://stackblitz.com) for instant preview.

---

## 🚀 Live Demo (Quickest Way)

1. Go to [stackblitz.com/edit/react](https://stackblitz.com/edit/react)
2. Replace `src/App.js` with the contents of the desired `.jsx` file
3. The app runs instantly in the browser — no install needed

---

## 👨‍💻 Author

**CodeAlpha Internship Submission**  
Tasks completed: Task 1 (E-commerce) · Task 2 (Social Media Platform)
